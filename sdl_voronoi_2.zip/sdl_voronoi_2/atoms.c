/**
 * Docs: http://wiki.libsdl.org/FrontPage
 * Tutorial: http://lazyfoo.net/tutorials/SDL/index.php
 */

#include <SDL.h>
#include <SDL_image.h>
#include <stdbool.h>

#include "sdl_playground.h"


#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

#define MAX_POINTS 10

#define SQR( x ) ( ( x ) * ( x ) )

typedef struct {
    SDL_Point p;
    SDL_Color c;
} AP;


float dist_eucl( AP * p, int x, int y ) {
    float x_diff = p->p.x - x;
    float y_diff = p->p.y - y;
    return SQR( x_diff ) + SQR( y_diff );
}

float dist_manahattan( AP * p, int x, int y ) {
    float x_diff = p->p.x - x;
    float y_diff = p->p.y - y;
    return fabs( x_diff ) + fabs( y_diff );
}

bool in_proximity( AP * p, int x, int y ) {
    if ( dist_manahattan( p, x, y ) < 5.0 ) {
        return true;
    }
    return false;
}

int main() {

    SDL_Window * win = NULL;
    SDL_Renderer * ren = NULL;
    
    bool initialized = sdl_playground_init( &win, &ren, WINDOW_WIDTH, WINDOW_HEIGHT );

    if ( !initialized ) 
    {
        sdl_playground_destroy( win, ren );
        return -1;
    }

    SDL_Texture * texture = SDL_CreateTexture( ren, SDL_PIXELFORMAT_RGB888,
                                               SDL_TEXTUREACCESS_STREAMING,
                                               WINDOW_WIDTH, WINDOW_HEIGHT );

    if ( !texture ) {
        exit( 1 );
    }

    AP * points = (AP *)malloc( MAX_POINTS * sizeof( points[ 0 ] ) );

    int no_points = 2;

    points[ 0 ].p.x = 20;
    points[ 0 ].p.y = 20;
    points[ 0 ].c.r = rand() % 256; 
    points[ 0 ].c.g = rand() % 256;
    points[ 0 ].c.b = rand() % 256;
    points[ 0 ].c.a = 255;

    points[ 1 ].p.x = 245;
    points[ 1 ].p.y = 324;
    points[ 1 ].c.r = rand() % 256; 
    points[ 1 ].c.g = rand() % 256;
    points[ 1 ].c.b = rand() % 256;
    points[ 1 ].c.a = 255;

    SDL_Event e;
    bool quit = false;
    int m_x, m_y;
    bool point_moving = false;
    int moving_ap_id = 0;

    float (*distance_fn[])(AP *, int, int) = {
        dist_eucl,
        dist_manahattan
    };

    int dist_fn_index = 0;

    while ( !quit ) { // main loop
        while ( SDL_PollEvent( &e ) ) {
            if ( e.type == SDL_QUIT ) {
                quit = true;
            }
            else if ( e.type == SDL_KEYDOWN ) { // key pressed down
                if ( e.key.keysym.sym == SDLK_r ) {
                    quit = true;
                }
                if ( e.key.keysym.sym == SDLK_SPACE ) {
                    dist_fn_index = 1 - dist_fn_index;
                }
            }
            else if (e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT) { // mouse button released
                m_x = e.button.x;
                m_y = e.button.y;

                point_moving = false;
            }
            else if ( e.type == SDL_MOUSEBUTTONDOWN ) {
                if ( e.button.button == SDL_BUTTON_LEFT ) {
                    m_x = e.button.x;
                    m_y = e.button.y;

                    for ( int i = 0; i < no_points; i++ ) {
                        AP * p = &points[ i ];
                        if ( in_proximity( p, m_x, m_y ) ) {
                            point_moving = true;
                            moving_ap_id = i;
                        }
                    }
                }
                else if ( e.button.button == SDL_BUTTON_RIGHT ) {
                    m_x = e.button.x;
                    m_y = e.button.y;

                    if ( no_points < MAX_POINTS ) {
                        AP * point = &points[ no_points ];

                        point->p.x = m_x;
                        point->p.y = m_y;

                        point->c.r = rand() % 256;
                        point->c.g = rand() % 256;
                        point->c.b = rand() % 256;
                        point->c.a = 255;

                        no_points++;
                    }
                }
            }
            else if (e.type == SDL_MOUSEMOTION) { // mouse movement
                m_x = e.button.x;
                m_y = e.button.y;

                if ( point_moving ) {
                    points[ moving_ap_id ].p.x = m_x;
                    points[ moving_ap_id ].p.y = m_y;
                }
            }
        }

        SDL_SetRenderDrawColor(ren, 0, 0, 0, 255);
        SDL_RenderClear(ren);

        SDL_Rect rect;
        rect.x = 0;
        rect.y = 0;
        rect.w = WINDOW_WIDTH;
        rect.h = WINDOW_HEIGHT;

        void * pixels;
        int pitch;
        SDL_PixelFormat * fmt;
        Uint32 format = SDL_GetWindowPixelFormat( win );
        fmt = SDL_AllocFormat( format );
        SDL_LockTexture( texture, NULL, &pixels, &pitch );


        for ( int y = 0; y < WINDOW_HEIGHT; y++ ) {
            for ( int x = 0; x < WINDOW_WIDTH; x++ ) {
                int closest = 0;
                float dist_closest = distance_fn[ dist_fn_index ]( &points[ closest ], x, y );
                for ( int p = 1; p < no_points; p++ ) {
                    float dist_p = distance_fn[ dist_fn_index ]( &points[ p ], x, y );
                    if ( dist_p < dist_closest ) {
                        closest = p;
                        dist_closest = dist_p;
                    }
                }

                AP * point = &points[ closest ];
                ((Uint32 *)pixels)[ x + y * WINDOW_WIDTH ] = SDL_MapRGB(
                     fmt, point->c.r, point->c.g, point->c.b );

            }
        }
        
        for ( int i = 0; i < no_points; i++ ) {
            AP * point = &points[ i ];
            SDL_Rect r = { .w = 4, .h = 4, .x = point->p.x - 2, .y = point->p.y - 2 };

            for ( int yy = 0; yy < r.h; yy++ ) {
                for ( int xx = 0; xx < r.w; xx++ ) {
                    ((Uint32 *)pixels)[ ( xx + r.x ) + 
                                       (( yy + r.y ) * WINDOW_WIDTH ) ] =
                                       SDL_MapRGB( fmt, 255, 255, 255 );
                }
            }
        }



        SDL_UnlockTexture( texture );
        SDL_FreeFormat( fmt );

        SDL_RenderCopyEx( ren, texture, NULL, &rect, 0, NULL, 0 );
        SDL_RenderPresent(ren);

        SDL_Delay( 1000 / 60.0 );
    }

    sdl_playground_destroy( win, ren );

    return 0;
}
